
<?php if(Session::has('success') || Session::has('error') || count($errors) > 0): ?>
<div class="box-body">
	<?php if(Session::has('success')): ?>
		<div class="alert alert-success alert-dismissible messageBody" style="display: none;">
		    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
		    <?php echo e(Session::get('success')); ?>

		</div>
	<?php elseif(Session::has('error')): ?>
		<div class="alert alert-warning alert-dismissible messageBody" style="display: none;">
		    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
		    <?php echo e(Session::get('error')); ?>

		</div>
	<?php endif; ?>

	<?php if(count($errors->all()) > 0): ?>
		<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="alert alert-warning alert-dismissible messageBody" style="display: none;">
			    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			    <?php echo e($error); ?>

			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endif; ?>
</div>
<?php endif; ?>

<!-- //Message from Ajax request// -->
<div class="box-body box-body-second" style="display: none;">
	<div class="alert alert-success alert-dismissible messageBodySuccess" style="display: none;">
	    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
	    <span></span>
	</div>
	<div class="alert alert-warning alert-dismissible messageBodyError" style="display: none;">
	    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
	    <span></span>
	</div>
</div>

<!-- Script for show hide -->
<script type="text/javascript">
	$(".messageBody").slideDown(1000).delay(3000).slideUp(1000);
</script>

