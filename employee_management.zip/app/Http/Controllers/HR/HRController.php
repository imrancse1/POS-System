<?php

namespace App\Http\Controllers\HR;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Custom\Helper;
use App\Models\Settings\Country;
use App\Models\Settings\Division;
use App\Models\Settings\City;
use App\Models\HR\PersonalInfo;
use App\Models\HR\PermanentAddress;
use App\Models\HR\PresentAddress;
use App\Models\HR\EmergencyCommunicationAddress;
use App\Models\HR\JobInfo;
use App\Models\HR\ExtraInfo;
use Carbon\Carbon;
use Session;
use App\User;
use DB;
use Auth;
use Redirect,Response,Config;
use DataTables;
class HRController extends Controller
{
    public $view_page_url;
    public function __construct()
    {
        $this->view_page_url = 'hr.employee.';
    }
    public function employeeDetails()
    {
        $countries = ['' => 'Please Select a Country'] +
            Country::where('status',1)
                ->pluck('country_name','country_id')
                ->all();

            $personalInforations = PersonalInfo::whereIn('status', [0,1])->get();           
        return view($this->view_page_url.'employee',compact('countries','personalInforations'));
    }

    public function countryWiseDivisionList($countryId)
    {
        return Division::where('status',1)
            ->where('country_id',$countryId)
            ->get();
    }
    public function divisionWiseCityList($divisionId)
    {
        return City::where('status',1)
            ->where('division_id',$divisionId)
            ->get();
    }

    //present
     public function presentCountryWiseDivisionList($presentCountryId)
    {
        return Division::where('status',1)
            ->where('country_id',$presentCountryId)
            ->get();
    }
    public function presentDivisionWiseCityList($presentDivisionId)
    {
        return City::where('status',1)
            ->where('division_id',$presentDivisionId)
            ->get();
    }
    //Emergency
    public function emergencyCountryWiseDivisionList($emergencyCountryId)
    {
        return Division::where('status',1)
            ->where('country_id',$emergencyCountryId)
            ->get();
    }
    public function emergencyDivisionWiseCityList($emergencyDivisionId)
    {
        return City::where('status',1)
            ->where('division_id',$emergencyDivisionId)
            ->get();
    }

        public function savePersonalInfoDetails(Request $request)
    {
        //return $request->no_of_child;
        // return $request->file('image_path');
        // exit();
        $presentDate = Carbon::now();
        $dob = Carbon::parse($request->dob);
        $birthdayDiff = $presentDate->diff($dob);
        $birthDate = $birthdayDiff->format('%y.%m');
        // $no_of_child=0;
        // $no_of_child = $no_of_child + $request->no_of_child;
        $from = Carbon::parse($request->from);
        $to = Carbon::parse($request->to);
        $diffBetweenTwoDates = $to->diff($from);
        $totalYearMonth = $diffBetweenTwoDates->format('%y.%m');
        
        DB::beginTransaction();
        try{
            $saveInfo = PersonalInfo::insertGetId([
                'name' => $request->name,
                'mobile_number' => $request->mobile_number,
                'father_name' => $request->father_name,
                'father_mobile_number' => $request->father_mobile_number,
                'mother_name' => $request->mother_name,
                'mother_mobile_number' => $request->mother_mobile_number,
                'education_qualification' => $request->education_qualification,
                'religion' => $request->religion,
                'dob' => date('Y-m-d',strtotime($request->dob)),
                'total_year' => $birthDate,
                'national_id' => $request->national_id,
                'marital_status' => $request->marital_status,
                'no_of_child' => $request->no_of_child,
                'created_by'  => Auth::user()->id,
                'created_at'  => Carbon::now()
            ]);


            if($saveInfo){
                //Image upload and update path at User
                if (strlen($request->file('image_path')) > 0) {
                    $folderPath = 'images/personal_image/';
                    $fileName = Helper::imageUploadRaw($saveInfo, $request->file('image_path'), $folderPath, 50, 75);
                    if ($fileName != null) {
                        $storeInfo = PersonalInfo::where('personal_info_id', $saveInfo)
                            ->update([
                                'image_path' => $fileName,
                                'updated_by' => Auth::user()->id
                            ]);
                    }
                }

                $saveJobInfo = JobInfo::insertGetId([
                    'personal_info_id' => $saveInfo,
                    'job_card_no' => $request->job_card_no,
                    'job_designation' => $request->job_designation,
                    'job_joining_date' => date('Y-m-d',strtotime($request->job_joining_date)),
                    'job_section' => $request->job_section,
                    'job_reference_name' => $request->job_reference_name,
                    'j_mobile_no' => $request->j_mobile_no,
                    'job_factory_name' => $request->job_factory_name,
                    'job_exp_designation' => $request->job_exp_designation,
                    'from' => Carbon::parse($request->from),
                    'to' => Carbon::parse($request->to),
                    'total_year_job_exp' => $totalYearMonth,
                    'created_at' => date('Y-m-d H:i:s'),
                    'created_by' => Auth::user()->id
                ]);

                $savePermanentAddress = PermanentAddress::insertGetId([
                    'personal_info_id' => $saveInfo,
                    'country_id' => $request->country_id,     
                    'division_id' => $request->division_id,     
                    'city_id' => $request->city_id,     
                    'permanent_village' => $request->village,     
                    'permanent_post_office' => $request->post_office,     
                    'permanent_upzila' => $request->up_zila,
                    'created_at' => Carbon::now(),
                    'created_by' => Auth::user()->id     
                ]);

                $savePermanentAddress = PresentAddress::insertGetId([
                    'personal_info_id' => $saveInfo,
                    'country_id' => $request->Present_country_id,     
                    'division_id' => $request->present_division_id,     
                    'city_id' => $request->present_city_id,     
                    'present_village' => $request->present_road,     
                    'present_post_office' => $request->present_post_office,     
                    'present_upzila' => $request->present_up_zila,
                    'created_at' => Carbon::now(),
                    'created_by' => Auth::user()->id     
                ]);

                $savePermanentAddress = EmergencyCommunicationAddress::insertGetId([
                    'personal_info_id' => $saveInfo,
                    'country_id' => $request->emergency_country_id,     
                    'division_id' => $request->emergency_division_id,     
                    'city_id' => $request->emergency_city_id,     
                    'emg_comm_village' => $request->emergency_village,     
                    'emg_comm_post_office' => $request->emergency_post_office,     
                    'emg_comm_upzila' => $request->emergency_up_zila,
                    'emg_comm_mob_number' => $request->emergency_mobile,
                    'created_at' => Carbon::now(),
                    'created_by' => Auth::user()->id     
                ]);

                $saveExtraInfo = ExtraInfo::insertGetId([
                    'personal_info_id' => $saveInfo,
                    'chairman_name' => $request->chairman_name,     
                    'chairman_m_number' => $request->chairman_m_number,     
                    'member_name' => $request->member_name,     
                    'member_m_number' => $request->member_m_number,     
                    'allegation_inthana' => $request->allegation_inthana,     
                    'give_reason' => $request->give_reason,
                    'created_at' => Carbon::now(),
                    'created_by' => Auth::user()->id     
                ]);

                if($saveExtraInfo && $request->allegation_inthana == 0){
                $updateExtraInfo = ExtraInfo::where('extra_info_id',                $saveExtraInfo)
                    ->update([
                        'give_reason' => 'No Complain',
                        'updated_at' => Carbon::now(),
                        'updated_by' => Auth::user()->id 
                    ]);
                }


                Session::flash('success', 'Prsonal Info Created Successfull');
                DB::commit();
            }else {
                Session::flash('error','Something Went Wrong');
                DB::rollback();
            }

        }catch(\Exception $e){
            DB::rollback();
            return $e;
            Session::flash('error',$e->errofInfo[2]);
        }
        return redirect()->route('hr.employee');
    }


    public function singleViewEmployee($id)
    {
        $employeeDetails = PersonalInfo::where('personal_info_id',$id)->first();
        // echo "<pre>";
        // print_r($employeeDetails->extraInformation);
        // echo "</pre>";
        // exit();
        return view('hr.employee.singleViewEmployee',compact('employeeDetails'));
    }

    public function updateStatus($modelReference, $action, $id)
    {
        $modelName = '';
        foreach (explode('-', $modelReference) as $value) {
            $modelName .= ucwords($value);
        }
        $filterColumn = implode('_', explode('-', $modelReference)) . '_id';
        $modelPath = 'App\Models\HR\\' . $modelName;
        $model = new $modelPath();

        DB::beginTransaction();
        try {
            $result = $model::where($filterColumn, $id)
                ->update([
                    'status' => Helper::getStatus($action),
                    'updated_by' => Auth::user()->id,
                ]);
            if ($result) {
                DB::commit();
                return response()->json(['success' => true, 'message' => ucwords($action) . ' Successfull !']);
            } else {
                DB::rollBack();
                return response()->json(['error' => true, 'message' => 'Something Went Wrong !']);
            }
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['error' => true, 'message' => $e->errorInfo[2]]);
        }
    }

     public function employeeEdit($id)
    {
         $employeeDetails = PersonalInfo::where('personal_info_id',$id)->first();
         $countries = Country::where('status',1)->get();
                
        return view($this->view_page_url.'employeeEdit',compact('employeeDetails','countries'));
    }

    public function updateEmployeeInfo(request $request,$personalInfoId)
    {
        //return $request->all();
        $findEmployeeData = PersonalInfo::where('personal_info_id',$personalInfoId)->first();

        if($findEmployeeData){
                $presentDate = Carbon::now();
                $dob = Carbon::parse($request->dob);
                $birthdayDiff = $presentDate->diff($dob);
                $birthDate = $birthdayDiff->format('%y.%m');
                $from = Carbon::parse($request->from);
                $to = Carbon::parse($request->to);
                $diffBetweenTwoDates = $to->diff($from);
                $totalYearMonth = $diffBetweenTwoDates->format('%y.%m');

           DB::beginTransaction();
           try{
                $updateInfo = PersonalInfo::where('personal_info_id',$findEmployeeData->personal_info_id)
                ->update([
                'name' => $request->name,
                'mobile_number' => $request->mobile_number,
                'father_name' => $request->father_name,
                'father_mobile_number' => $request->father_mobile_number,
                'mother_name' => $request->mother_name,
                'mother_mobile_number' => $request->mother_mobile_number,
                'education_qualification' => $request->education_qualification,
                'religion' => $request->religion,
                'dob' => date('Y-m-d',strtotime($request->dob)),
                'total_year' => $birthDate,
                'national_id' => $request->national_id,
                'marital_status' => $request->marital_status,
                'no_of_child' => $request->no_of_child,
                'created_by'  => Auth::user()->id,
                'created_at'  => Carbon::now()
            ]);

            if($updateInfo){
                //Image upload and update path at User
                if (strlen($request->file('image_path')) > 0) {
                    $oldImage = $findEmployeeData->image_path;
                    $folderPath = 'images/personal_image/';
                    $fileName = Helper::imageUploadRaw($updateInfo, $request->file('image_path'), $folderPath, 50, 75);
                    if ($fileName != null) {
                        $storeInfo = PersonalInfo::where('personal_info_id', $findEmployeeData->personal_info_id)
                            ->update([
                                'image_path' => $fileName,
                                'updated_by' => Auth::user()->id
                            ]);
                        if (file_exists(public_path() . '/' . $folderPath . '/' . $fileName)) {

                                if (file_exists(public_path() . '/' . $folderPath . $oldImage)) {
                                    unlink(public_path() . '/' . $folderPath . $oldImage);
                                }
                            }    
                    }
                }
                Session::flash('success','Personal Info Updated Successfull');
                DB::commit();
               
            }else {
                Session::flash('error','Something Went Wrong');
                DB::rollback();
            }

           }catch(\Exception $e){
            DB::rollback();
            return $e;
            Session::flash('error',$e->errofInfo[2]);
        }    
    }
        
     return redirect()->route('hr.employee');
    }

    














    public function employeeReports(Request $request)
    {
        //return $request->all();
        $name = $request->name;
        $email = $request->email;
        if($request->name && $request->email){
            $name = $request->name;
            $email = $request->email;
        }
        return view('hr.employee.employeeReports',compact('name','email'));
    }

    public function getTestEmployeeReports(Request $request)
    {
        // return $request->all();
        if(isset($request->name) && isset($request->email)){
            $model = User::orderBy('id','ASC')
                ->where('name','like','%'.$request->name.'%')       
                ->where('email','like','%'.$request->email.'%')       
                ->get(); 
        }else if(isset($request->name)){
            $model = User::orderBy('id','ASC')
                ->where('name','like','%'.$request->name.'%')       
                ->get(); 
        }else if(isset($request->email)){
            $model = User::orderBy('id','ASC')
                ->where('email','like','%'.$request->email.'%')       
                ->get(); 
        }else{
            $model = [];
        }
        // dd($model);
         return Datatables::of($model)
            ->editColumn('status', function ($user) {
                $html = '';
                $html .= "<label class='label label-warning'";
                if ($user->status == 1) {
                    $html .= "style='display:none'";
                }
                $html .= ">Inactive</label>";

                $html .= "<label class='label label-success'";
                if ($user->status == 0) {
                    $html .= "style='display:none'";
                }
                $html .= ">Completed</label>";
                return $html;
            })
            ->addColumn('action', function ($user) {
                $html = '<a href="#" class="btn btn-xs btn-primary"> Edit </a>';
                return $html;
            })
            ->rawColumns(['id','name','email','status', 'action'])
            ->make();
        return view('hr.employee.employeeReports');    
    }

    public function searchAutoComplete(Request $request)
    {
          $search = $request->get('term');
      
          $result = User::where('name', 'LIKE', '%'. $search. '%')->get();
 
          return response()->json($result);
            
    } 

    

    
    

} 
