<?php

namespace App\Models\HR;

use Illuminate\Database\Eloquent\Model;

class JobInfo extends Model
{
    protected $table = 'job_infos';
    protected $primaryKey = 'job_info_id';

   
}
