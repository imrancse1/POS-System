<?php

namespace App\Models\HR;

use Illuminate\Database\Eloquent\Model;

class ExtraInfo extends Model
{
    protected $table = 'extra_infos';
    protected $primaryKey = 'extra_info_id';
}
