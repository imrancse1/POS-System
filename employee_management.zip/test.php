 public function updateEmployeeInfo(request $request,$personalInfoId)
    {
        //return $request->all();
        $findEmployeeData = PersonalInfo::where('personal_info_id',$personalInfoId)->first();

        if($findEmployeeData){
                $presentDate = Carbon::now();
                $dob = Carbon::parse($request->dob);
                $birthdayDiff = $presentDate->diff($dob);
                $birthDate = $birthdayDiff->format('%y.%m');
                $no_of_child=0;
                $no_of_child = $no_of_child + $request->no_of_child;
                $from = Carbon::parse($request->from);
                $to = Carbon::parse($request->to);
                $diffBetweenTwoDates = $to->diff($from);
                $totalYearMonth = $diffBetweenTwoDates->format('%y.%m');
        
        DB::beginTransaction();
        try{
            $saveInfo = PersonalInfo::where('personal_info_id',$findEmployeeData->personal_info_id)
            ->update([
                'name' => $request->name,
                'mobile_number' => $request->mobile_number,
                'father_name' => $request->father_name,
                'father_mobile_number' => $request->father_mobile_number,
                'mother_name' => $request->mother_name,
                'mother_mobile_number' => $request->mother_mobile_number,
                'education_qualification' => $request->education_qualification,
                'religion' => $request->religion,
                'dob' => date('Y-m-d',strtotime($request->dob)),
                'total_year' => $birthDate,
                'national_id' => $request->national_id,
                'marital_status' => $request->marital_status,
                'no_of_child' => $no_of_child,
                'created_by'  => Auth::user()->id,
                'created_at'  => Carbon::now()
            ]);


            if($saveInfo){
                //Image upload and update path at User
                if (strlen($request->file('image_path')) > 0) {
                    $oldImage = $findEmployeeData->image_path;
                    $folderPath = 'images/personal_image/';
                    $fileName = Helper::imageUploadRaw($saveInfo, $request->file('image_path'), $folderPath, 50, 75);
                    if ($fileName != null) {
                        $storeInfo = PersonalInfo::where('personal_info_id', $findEmployeeData->personal_info_id)
                            ->update([
                                'image_path' => $fileName,
                                'updated_by' => Auth::user()->id
                            ]);
                        if (file_exists(public_path() . '/' . $folderPath . '/' . $fileName)) {

                                if (file_exists(public_path() . '/' . $folderPath . $oldImage)) {
                                    unlink(public_path() . '/' . $folderPath . $oldImage);
                                }
                            }    
                    }
                }

                $saveJobInfo = JobInfo::where('job_info_id',$findEmployeeData->jobInformation->job_info_id)
                ->update([
                    'personal_info_id' => $saveInfo,
                    'job_card_no' => $request->job_card_no,
                    'job_designation' => $request->job_designation,
                    'job_joining_date' => date('Y-m-d',strtotime($request->job_joining_date)),
                    'job_section' => $request->job_section,
                    'job_reference_name' => $request->job_reference_name,
                    'j_mobile_no' => $request->j_mobile_no,
                    'job_factory_name' => $request->job_factory_name,
                    'job_exp_designation' => $request->job_exp_designation,
                    'from' => Carbon::parse($request->from),
                    'to' => Carbon::parse($request->to),
                    'total_year_job_exp' => $totalYearMonth,
                    'created_at' => date('Y-m-d H:i:s'),
                    'created_by' => Auth::user()->id
                ]);

                $savePermanentAddress = PermanentAddress::where('permanent_address_id',$findEmployeeData->permanentAddress->permanent_address_id)
                ->update([
                    'personal_info_id' => $saveInfo,
                    'country_id' => $request->Permanent_country_id,     
                    'division_id' => $request->Permanent_division_id,     
                    'city_id' => $request->permanent_city_id,     
                    'permanent_village' => $request->village,     
                    'permanent_post_office' => $request->post_office,     
                    'permanent_upzila' => $request->up_zila,
                    'created_at' => Carbon::now(),
                    'created_by' => Auth::user()->id     
                ]);

                $savePermanentAddress = PresentAddress::where('present_address_id',$findEmployeeData->presentAddress->present_address_id)
                ->update([
                    'personal_info_id' => $saveInfo,
                    'country_id' => $request->present_country_id,     
                    'division_id' => $request->present_division_id,     
                    'city_id' => $request->present_city_id,     
                    'present_village' => $request->present_road,     
                    'present_post_office' => $request->present_post_office,     
                    'present_upzila' => $request->present_up_zila,
                    'created_at' => Carbon::now(),
                    'created_by' => Auth::user()->id     
                ]);

                $savePermanentAddress = EmergencyCommunicationAddress::where('emergency_communication_address_id',$findEmployeeData->emergencyCommunicationAddress->emergency_communication_address_id)
                ->update([
                    'personal_info_id' => $saveInfo,
                    'country_id' => $request->emergency_country_id,     
                    'division_id' => $request->emergency_division_id,     
                    'city_id' => $request->emergency_city_id,     
                    'emg_comm_village' => $request->emergency_village,     
                    'emg_comm_post_office' => $request->emergency_post_office,     
                    'emg_comm_upzila' => $request->emergency_up_zila,
                    'emg_comm_mob_number' => $request->emergency_mobile,
                    'created_at' => Carbon::now(),
                    'created_by' => Auth::user()->id     
                ]);

                $saveExtraInfo = ExtraInfo::where('extra_info_id',$findEmployeeData->extraInformation->extra_info_id)
                ->update([
                    'personal_info_id' => $saveInfo,
                    'chairman_name' => $request->chairman_name,     
                    'chairman_m_number' => $request->chairman_m_number,     
                    'member_name' => $request->member_name,     
                    'member_m_number' => $request->member_m_number,     
                    'allegation_inthana' => $request->allegation_inthana,     
                    'give_reason' => $request->give_reason,
                    'created_at' => Carbon::now(),
                    'created_by' => Auth::user()->id     
                ]);

                if($saveExtraInfo && $request->allegation_inthana == 0){
                $updateExtraInfo = ExtraInfo::where('extra_info_id',                $saveExtraInfo)
                    ->update([
                        'give_reason' => 'No Complain',
                        'updated_at' => Carbon::now(),
                        'updated_by' => Auth::user()->id 
                    ]);
                }


                Session::flash('success', 'Personal Info Updated Successfull');
                DB::commit();
            }else {
                Session::flash('error','Something Went Wrong');
                DB::rollback();
            }

        }catch(\Exception $e){
            DB::rollback();
            return $e;
            Session::flash('error',$e->errofInfo[2]);
        }
}

     return redirect()->route('hr.employee');
    }
