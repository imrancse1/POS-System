<?php 

Route::group(['prefix' => 'hr','middleware' => 'auth'],function(){

	Route::get('/employee', [
		'as' => 'hr.employee',
		'uses' => 'HRController@employeeDetails'
	]);

	Route::post('/save-personalInfo', [
		'as' => 'hr.save-personalInfo.post',
		'uses' => 'HRController@savePersonalInfoDetails'
	]);

	Route::get('/countryWiseDivision/{countryId}', [
		'as' => 'hr.countryWiseDivision',
		'uses' => 'HRController@countryWiseDivisionList'
	]);
	Route::get('/divisionWiseCity/{divisionId}', [
		'as' => 'hr.divisionWiseCity',
		'uses' => 'HRController@divisionWiseCityList'
	]);
//present
	Route::get('/presentCountryWiseDivision/{presentCountryId}', [
		'as' => 'hr.presentCountryWiseDivision',
		'uses' => 'HRController@presentCountryWiseDivisionList'
	]);
	Route::get('/presentDivisionWiseCity/{presentDivisionId}', [
		'as' => 'hr.presentDivisionWiseCity',
		'uses' => 'HRController@presentDivisionWiseCityList'
	]);
//Emergency 
	Route::get('/emergencyCountryWiseDivision/{emergencyCountryId}', [
		'as' => 'hr.emergencyCountryWiseDivision',
		'uses' => 'HRController@emergencyCountryWiseDivisionList'
	]);
	Route::get('/emergencyDivisionWiseCity/{emergencyDivisionId}', [
		'as' => 'hr.emergencyDivisionWiseCity',
		'uses' => 'HRController@emergencyDivisionWiseCityList'
	]);	
	
	Route::get('/single-employee-view/{id}', [
		'as' => 'hr.single-employee-view',
		'uses' => 'HRController@singleViewEmployee'
	]);

	Route::get('update-status/{modelReference}/{action}/{id}', [
        'as' => 'hr.update-status',
        'uses' => 'HRController@updateStatus'
    ]);

//Edit 
    Route::get('/employee-edit/{id}', [
		'as' => 'hr.employee-view',
		'uses' => 'HRController@employeeEdit'
	]);

//permanent
	Route::get('/employee-edit/countryWiseDivision/{countryId}', [
		'as' => 'hr.countryWiseDivision',
		'uses' => 'HRController@countryWiseDivisionList'
	]);

	Route::get('/employee-edit/divisionWiseCity/{divisionId}', [
		'as' => 'hr.divisionWiseCity',
		'uses' => 'HRController@divisionWiseCityList'
	]);
//present
	Route::get('/employee-edit/presentCountryWiseDivision/{presentCountryId}', [
		'as' => 'hr.presentCountryWiseDivision',
		'uses' => 'HRController@presentCountryWiseDivisionList'
	]);
	Route::get('/employee-edit/presentDivisionWiseCity/{presentDivisionId}', [
		'as' => 'hr.presentDivisionWiseCity',
		'uses' => 'HRController@presentDivisionWiseCityList'
	]);
//Emergency 
	Route::get('/employee-edit/emergencyCountryWiseDivision/{emergencyCountryId}', [
		'as' => 'hr.emergencyCountryWiseDivision',
		'uses' => 'HRController@emergencyCountryWiseDivisionList'
	]);
	Route::get('/employee-edit/emergencyDivisionWiseCity/{emergencyDivisionId}', [
		'as' => 'hr.emergencyDivisionWiseCity',
		'uses' => 'HRController@emergencyDivisionWiseCityList'
	]);	

	Route::post('/update-employee-info/{personalInfoId}', [
		'as' => 'hr.update-employee-info.post',
		'uses' => 'HRController@updateEmployeeInfo'
	]);
    //Yajara Search
    Route::get('/employeeReports', [
    	'as' => 'hr.employeeReports',
    	'uses' => 'HRController@employeeReports'
    ]);

    Route::any('/getEmployeeReportsData', [
    	'as' => 'hr.getEmployeeReportsData.post',
    	'uses' => 'HRController@employeeReports'
    ]);

    Route::post('get-test-employee-reports', [
    	'as' => 'hr.get-test-employee-reports',
    	'uses' => 'HRController@getTestEmployeeReports'
    ]);

    Route::get('/searchAutoComplete', [
    	'as' => 'hr.searchAutoComplete',
    	'uses' => 'HRController@searchAutoComplete'
    ]);

   

    

});